
#ifndef _ABLOCKSIOTMQTTETHERNET_h
#define _ABLOCKSIOTMQTTETHERNET_h

//#define INFO_CONNECTION "W5100"

#include "ABlocksIOTDefines.h"
#include <Ethernet.h>
#include "ABlocksIOTMQTTEthernetClient.h"

#endif
